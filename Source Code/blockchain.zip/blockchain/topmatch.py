from fastapi import FastAPI
import requests
from bs4 import BeautifulSoup

app = FastAPI()

def match(hai):
        score = hai.find('span', class_='match-fixture__score score').text.replace(' ', '')
        home = hai.find_all('span', class_='match-fixture__team-name')[0].abbr['title']
        away = hai.find_all('span', class_='match-fixture__team-name')[1].abbr['title']
        return f"{home} {score} {away}"

def recent_matches(name):
        name = name.replace('-', ' ')
        
        url = "https://www.premierleague.com/tables"
   
        response = requests.get(url)

        if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                teams = soup.find_all('td', class_='league-table__team')
                team_list = []
                for team in teams:
                        team_name = team.find('span', class_='long')
                        team_list.append(team_name.text.strip())

                if name not in team_list:
                        return []
                idx = team_list.index(name)

                content = soup.find_all('td', class_='league-table__form form hideMed')[idx]
                for team in [content]:
                        hai = team.find_all('a', class_='tooltipContainer linkable tooltip-link tooltip-right')
                        
                match_list = []
                for i in range(5):
                        match_list.append(match(hai[i]))
                        
                return match_list
print(recent_matches('Manchester-United'))

# API for recent matchs
@app.get("/matches/{team_name}")
def get_recent_matches(team_name: str):
        return recent_matches(team_name)