const Card = artifacts.require("Card");

contract("Card", (accounts) => {
  let cardInstance;

  before(async () => {
    cardInstance = await Card.deployed();
  });

  it("should mint a new card with the correct owner", async () => {
    const userId = 1; // Assuming userId 1 for testing
    const cardId = "TestCard";
    const userId2 = 2; // Assuming userId 2 for testing
    const cardId2 = "TestCard2";

    // const tokenId = await cardInstance.mint(cardId, userId, { from: accounts[0] });
    const receipt = await cardInstance.mint(cardId, "0.15", userId, "19-02-2023", { from: accounts[0] });
    const tokenId = receipt.logs[0].args.tokenId;

    // const tokenId2 = await cardInstance.mint(cardId2, userId2, { from: accounts[0] });
    const receipt2 = await cardInstance.mint(cardId2, "0.15", userId2, "19-02-23", { from: accounts[0] });
    const tokenId2 = receipt2.logs[0].args.tokenId;
    
    assert.equal(await cardInstance.owner_of(tokenId), userId, "Incorrect token owner");
    assert.equal(await cardInstance.ownerOf(tokenId), accounts[0], "Incorrect owner");
    assert.equal(await cardInstance.owner_of(tokenId2), userId2, "Incorrect token owner");
    assert.equal(await cardInstance.ownerOf(tokenId2), accounts[0], "Incorrect owner");
  });

  it("should not mint a card if it already exists", async () => {
    const userId = 2; // Assuming userId 2 for testing
    const cardId = "TestCard"; // Use the same cardId as before
    try {
      await cardInstance.mint(cardId, "0.15", userId, "19-02-23", { from: accounts[1] });
      assert.fail("Expected error not thrown");
    } catch (error) {
      assert(error.message.includes("Card already exists"), "Unexpected error message");
    }
  });

  it("should burn a card", async () => {
    const cardId = "TestCard";
    const tokenId = await cardInstance.get_token_id_from_card_id(cardId);
    await cardInstance.burn(tokenId, { from: accounts[0] });

    try {
      await cardInstance.ownerOf(tokenId);
      assert.fail("Expected error not thrown");
    } catch (error) {
      assert(error.message.includes("ERC721: owner query for nonexistent token"), "Unexpected error message");
    }
  });

  it("should change ownership of a card", async () => {
    const cardId = "NewCard";
    userId = 2; // Assuming userId 2 for testing
    await cardInstance.mint(cardId, "0.15", userId, "19-02-23", { from: accounts[0] });
    const tokenId = await cardInstance.get_token_id_from_card_id(cardId);

    const newUserId = 3; // Assuming userId 3 for testing
    await cardInstance.change_ownership(tokenId, newUserId, { from: accounts[0] });

    assert.equal(await cardInstance.ownerOf(tokenId), accounts[0], "Incorrect new owner");
  });

  it("should burn a card and check", async () => {
    const cardId = "BurnNewCard";
    const userId = 4; // Assuming userId 4 for testing
    
    console.log("Get token id");
    await cardInstance.mint(cardId, "0.15", userId, "19-02-2023", { from: accounts[0] });
    const tokenId = await cardInstance.get_token_id_from_card_id(cardId);
    // check if the token exists
    console.log(tokenId);
    const date = await cardInstance.date_of(tokenId);
    console.log(date);
    const price = await cardInstance.price_of(tokenId); 
    // convert price to string
    console.log(price);
    console.log("Burn");
    await cardInstance.burn(tokenId, { from: accounts[0] });

    console.log("Mint");
    await cardInstance.mint(cardId, "0.15", userId, "19-02-23", { from: accounts[0] });

    console.log("Done");
  });
  
});
