module.exports = {
    networks: {
        AWS: {
            networkCheckTimeout: 10000, 
            host: "3.222.198.122",
            port: 8545,
            network_id: "9999",
            from: "0x2b51e8BFF096fa2719e5e843BD65C2B51b6f64Fb",
            gas: 4783278
        }
    }
}