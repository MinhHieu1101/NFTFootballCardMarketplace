	<script src="blockchain/truffle-contract.js"></script>
    <script src="blockchain/web3.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script>
            
$(document).ready(function() {
    $('#buyNowBtn').click(async function() {
            var userId = $('#userId').val();
            var cardId = $('#cardId').val();
            var price = $('#price').val();
			let card_price = price.toString();
			var imageURL = $('#imageURL').val();
			//MySQL DATETIME Format
			var purchaseDate = new Date().toISOString().slice(0, 19).replace('T', ' ');
			
            const web3 = new Web3("http://3.222.198.122:8545");
            
            const accounts = await web3.eth.getAccounts();
            const balance =await web3.eth.getBalance(accounts[0]);
            
            console.log(accounts);
            var web3Provider = new Web3.providers.HttpProvider("http://3.222.198.122:8545");
            console.log(web3Provider);
            console.log(await web3.eth.getBlockNumber());

            $.getJSON("blockchain/build/contracts/Card.json", async function(data){
                console.log(data);
                var CardArtifact = data;
                var CardContract = TruffleContract(CardArtifact);
                console.log(CardContract);
                CardContract.setProvider(web3Provider);
                var card_instance;

                await CardContract.deployed().then(async function(instance){
                    card_instance = instance;
                    await card_instance.mint(cardId, card_price, userId, purchaseDate, {from: '0x2b51e8BFF096fa2719e5e843BD65C2B51b6f64Fb'}).then(function(){
                        console.log("Mint: ", accounts[accounts.length -1]);
                    })
             
                    var token_id = await card_instance.get_token_id_from_card_id(cardId, {from: '0x2b51e8BFF096fa2719e5e843BD65C2B51b6f64Fb'});
					//Convert BigNumber to string
					let tokenIdString = token_id.toString(); 
					//Parse string to integer
					let tokenId = parseInt(tokenIdString); 
					console.log("Token ID: ", tokenId);
					console.log("Purchase Date: ", card_instance.date_of(token_id));
					console.log("Price: ", card_instance.price_of(token_id));
					
						//Perform the AJAX call
						$.ajax({
							url: 'insert_transaction.php',
							method: 'POST',
							data: {
								token_id: tokenId,
								card_id: cardId,
								user_id: userId,
								purchase_date: purchaseDate,
								price: price,
								card_image: imageURL
							},
							success: function(response) {
								// Handle success
								console.log('Transaction successful:', response);
								$('#response').html('<div class="alert alert-success"><p class="alert-content">' + response.message + '</p></div>');
							},
							error: function(xhr, status, error) {
								// Handle errors
								console.error('Transaction failed:', status, error);
								alert("Result: " + status + " " + error + " " + xhr.status + " " + xhr.statusText);
							}
						});
					console.log("Transaction finished!");
				});
			});
    });
});

    </script>