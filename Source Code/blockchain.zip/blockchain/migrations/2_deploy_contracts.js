// const HelloWorld = artifacts.require("./HelloWorld");

// module.exports = function(deployer) {
//     deployer.deploy(HelloWorld);
// };

const Card = artifacts.require("Card");

module.exports = function(deployer) {
    deployer.deploy(Card);
};